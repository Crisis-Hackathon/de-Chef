//
//  ApplicationApp.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 18/04/23.
//

import SwiftUI

@main
struct ApplicationApp: App {
    var body: some Scene {
        WindowGroup {
//            ContentView()
//            ContentView2()
            NavigationStack {
//                ContentView2()
                MainView()
            }
        }
    }
}
