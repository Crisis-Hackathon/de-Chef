//
//  ReciepeModelCreator.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 17/02/24.
//

import Foundation
import CreateML


class MLDataManager {
    static let shared = MLDataManager()
    let staticKey = "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"
    
    func createMl() {

        // Load your dataset
        let data = try! MLDataTable(contentsOf: URL(fileURLWithPath: "path/to/your/dataset.csv"))

        // Split the data into training and testing sets
        let (trainingData, testingData) = data.randomSplit(by: 0.8, seed: 42)

        // Create a text classifier using Create ML
        let recipeClassifier = try! MLTextClassifier(trainingData: trainingData, textColumn: "ingredients", labelColumn: "recipe_name")

        // Evaluate the model
        let evaluation = recipeClassifier.evaluation(on: trainingData, textColumn: "ingredients", labelColumn: "recipeName")
        let metrics = evaluation
        print("Evaluation Metrics: \(metrics)")

    }
}
