//
//  ImageCardView.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 18/02/24.
//

import SwiftUI

struct ImageCardView: View {
    
    let image: UIImage?
    @EnvironmentObject var viewm: ImageSwipeViewModel
    
    @State var offset: CGFloat = 0
    @GestureState var isDragging: Bool = false
    @State var endSwipe: Bool = false
    @Binding var foodsArray: [UIImage?]
    
    
    
    
    var body: some View {
        GeometryReader(content: { geometry in
            let size = geometry.size
            
            let index = CGFloat(findIndex(image: image))
            
            let topOffSet = (index <= 2 ? index : 2) * 15
            
            ZStack {
                if let image = self.image {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: size.width - topOffSet, height: size.height)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .offset(y: -topOffSet)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        })
        .offset(x: offset)
        .contentShape(Rectangle().trim(from: 0, to: endSwipe ? 0 : 1))
        .gesture(
            DragGesture()
                .updating($isDragging, body: { value, out, _ in
                    out = true
                })
                .onChanged({ value in
                    let translation = value.translation.width
                    offset = (isDragging ? translation: .zero)
                })
                .onEnded({ value in
                    let width = getRect().width - 50
                    let translation = value.translation.width
                    
                    let checkingStatus = (translation > 0 ? translation : -translation)
                    
                    withAnimation {
                        if checkingStatus > (width / 2) {
//                            offset = (translation > 0 ? width : -width) * 2
                            endSwipe = true
                            endSwipeAction()
                            offset = .zero
                        } else {
                            offset = .zero
                        }
                    }
                    
                })
        )
    }
}


extension ImageCardView {
    
    private func getRect() -> CGRect {
        return UIScreen.main.bounds
    }
    
    func endSwipeAction() {
        viewm.goodsArray.move(image, to: viewm.goodsArray.endIndex-1)
        foodsArray.move(image, to: foodsArray.endIndex-1)
//        viewm.goodsArray.append(image)
    }
    
    func findIndex(image: UIImage?) -> Int {
        let index = foodsArray.reversed().firstIndex { image1 in
            return image1 == image
        } ?? 0
        
        return index
    }
}

#Preview {
    ImageCardView(image: UIImage(systemName: "heart"), foodsArray: .constant([UIImage(systemName: "heart"), UIImage(systemName: "house")]))
        .environmentObject(ImageSwipeViewModel())
}


extension Array where Element: Equatable
{
    mutating func move(_ element: Element, to newIndex: Index) {
        if let oldIndex: Int = self.firstIndex(of: element) { self.move(from: oldIndex, to: newIndex) }
    }
}

extension Array
{
    mutating func move(from oldIndex: Index, to newIndex: Index) {
        // Don't work for free and use swap when indices are next to each other - this
        // won't rebuild array and will be super efficient.
        if oldIndex == newIndex { return }
        if abs(newIndex - oldIndex) == 1 { return self.swapAt(oldIndex, newIndex) }
        self.insert(self.remove(at: oldIndex), at: newIndex)
    }
}
