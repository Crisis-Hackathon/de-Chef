//
//  CustomTabBar.swift
//  deChef
//
//  Created by Muhammadjon Madaminov on 18/02/24.
//

import SwiftUI


enum TabSelection {
    case home, history, saved, profile, add
    
    var symbolName: String {
        switch self {
        case .home:
            return "house"
        case .history:
            return "clock.badge"
        case .saved:
            return "bookmark"
        case .profile:
            return "person"
        case .add:
            return "questionmark"
        }
    }
    
    
    var name: String {
        switch self {
        case .home:
            return "Home"
        case .history:
            return "History"
        case .saved:
            return "Saved"
        case .profile:
            return "Profile"
        case .add:
            return "Ask"
        }
    }
}



struct CustomTabBar: View {
    
    @Binding var selectedTab: TabSelection
    @Namespace private var nameSpace
    @State private var tabBar: TabSelection = .home
    
    var body: some View {
        HStack(alignment: .bottom) {
            TabBarItems(tab: .add)
            TabBarItems(tab: .saved)
            
            HStack{
                Text("Home")
                    .fontWeight(.regular)
                    .foregroundStyle(tabBar != .home ? .gray : .purple)
                    .padding(.top, 25)
            }
            .overlay(alignment: .top) {
                Button(action: {
                    withAnimation(.spring) {
                        tabBar = .home
                    }
                }, label: {
                    Image(systemName: "house")
                        .font(.largeTitle)
                        .fontWeight(.regular)
                        .foregroundStyle(Color.white)
                        .padding()
                        .background(Color.purple)
                        .clipShape(RoundedRectangle(cornerRadius: 35))
                })
                .offset(y: -20)
                .shadow(color: .black.opacity(0.4), radius: 10, y: 3)
                .buttonStyle(.plain)
            }
            .padding(.bottom, 10)
            .padding(.horizontal, 10)
            
            TabBarItems(tab: .history)
            TabBarItems(tab: .profile)
        }
        .padding(.bottom, 10)
        .background(Color(UIColor.systemBackground).cornerRadius(20, corners: [.topLeft, .topRight]))
        .glassBlurView()
        .onChange(of: tabBar) { oldValue, newValue in
            selectedTab = newValue
        }
    }
}

extension CustomTabBar {
    @ViewBuilder private func TabBarItems(tab: TabSelection) -> some View {
        VStack {
            if tab == tabBar {
                RoundedRectangle(cornerRadius: 1)
                    .padding(.horizontal, 12)
                    .frame(height: 2.5)
                    .matchedGeometryEffect(id: "tabBarId", in: nameSpace)
                    .foregroundStyle(Color.purple)
            } else {
                RoundedRectangle(cornerRadius: 1)
                    .frame(height: 3)
                    .opacity(0)
            }
            
            Image(systemName: tab.symbolName)
                .font(.title2)
                .padding(.vertical, 5)
                .fontWeight(.regular)
                .frame(minHeight: 40)
            Text(tab.name)
                .font(.callout)
                .fontWeight(.regular)
        }
        .foregroundStyle(tabBar != tab ? .gray : .purple)
        .onTapGesture {
            withAnimation(.spring) {
                tabBar = tab
            }
        }
        .contentShape(Rectangle())
    }
}

#Preview {
    ZStack {
        Color.orange
        
        CustomTabBar(selectedTab: .constant(.history))
    }
}

