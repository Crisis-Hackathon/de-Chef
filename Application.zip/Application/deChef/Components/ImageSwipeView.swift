//
//  ImageSwipeView.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 18/02/24.
//

import SwiftUI


@MainActor
final class ImageSwipeViewModel: ObservableObject {
    
    @Published var goodsArray: [UIImage?] = []
    
    func setArray(array: [UIImage?]) {
        self.goodsArray = array
        print("setted")
    }
    
    func findIndex(image: UIImage?) -> Int {
        let index = goodsArray.reversed().firstIndex { image1 in
            return image1 == image
        } ?? 0
        
        return index
    }
}

struct ImageSwipeView: View {
    
    @Binding var goodsArray: [UIImage?]
    @StateObject var viewm = ImageSwipeViewModel()
    
    
    var body: some View {
        ZStack {
            ForEach(viewm.goodsArray, id: \.self) { goods in
                ImageCardView(image: goods, foodsArray: $viewm.goodsArray)
                    .environmentObject(viewm)
            }
        }
        .onChange(of: goodsArray, { oldValue, newValue in
            viewm.goodsArray = newValue
        })
        .onAppear {
            viewm.goodsArray = goodsArray
        }
        .padding()
    }
}




#Preview {
    ImageSwipeView(goodsArray: .constant([UIImage(systemName: "heart"), UIImage(systemName: "house"), UIImage(systemName: "flame")]))
}
