//
//  TransparentBlurModifier.swift
//  AdvancedBootCamp
//
//  Created by Muhammadjon Madaminov on 29/11/23.
//

import SwiftUI

extension View {
    
    public func glassBlurView(_ color: Color = Color(#colorLiteral(red: 0.1311095953, green: 0.121230863, blue: 0.2308914959, alpha: 1)).opacity(0.5)) -> some View {
        modifier(TransparentBlurModifier(color: color))
    }
    
    public func glassBlurView2(_ color: Color = Color(#colorLiteral(red: 0.1311095953, green: 0.121230863, blue: 0.2308914959, alpha: 1)).opacity(0.5)) -> some View {
        modifier(TransparentBlurModifier2(color: color))
    }
    
    
}


//    .cornerRadius(25, corners: [.topLeft, .topRight])

struct TransparentBlurModifier: ViewModifier {
    let color: Color
    
    func body(content: Content) -> some View {
        content
            .background(
                TransparentBlurView()
                    .blur(radius: 9, opaque: true)
                    .background(color.opacity(0.2))
                    .shadow(radius: 10, y: 5)
            )
            .cornerRadius(20)
            .overlay {
                RoundedRectangle(cornerRadius: 20)
                    .stroke(.white.opacity(0.25), lineWidth: 2)
                    
            }
    }
}


struct TransparentBlurModifier2: ViewModifier {
    let color: Color
    
    func body(content: Content) -> some View {
        content
            .background(
                TransparentBlurView()
                    .blur(radius: 9, opaque: true)
                    .background(color.opacity(0.2))
                    .shadow(radius: 10, y: 5)
            )
            .cornerRadius(25, corners: [.topLeft, .topRight])
            .overlay {
                Rectangle()
                    .stroke(Color.white.opacity(0.25), lineWidth: 2)
                    .cornerRadius(25, corners: [.topLeft, .topRight])
                    
            }
    }
}
