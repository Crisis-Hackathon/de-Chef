//
//  BackgroundView.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 18/02/24.
//

import SwiftUI

enum BlurType: String, CaseIterable {
    case clipped = "Clipped"
    case freestyle = "Free Style"
}




struct BackgroundView: View {
    @State var start = UnitPoint(x: 0,y: -2)
    @State var end = UnitPoint(x:4, y: 0)
    @Binding var changeOfView: Bool

    
    let timer = Timer.publish(every: 5, on: .main, in: .default).autoconnect()
    
    let colors: [Color] = [
        Color(#colorLiteral(red: 0.4508578777, green: 0.9882974029, blue: 0.8376303315, alpha: 1)), Color(#colorLiteral(red: 0.8549019694, green: 0.250980407, blue: 0.4784313738, alpha: 1)), Color(#colorLiteral(red: 0.1764705926, green: 0.01176470611, blue: 0.5607843399, alpha: 1)), Color(#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)),
    ]
    
    
    var body: some View {
        VStack {
            LinearGradient(gradient: Gradient(colors: colors), startPoint: start, endPoint: end)
                .onReceive(timer, perform: { _ in
                    withAnimation(.spring(duration: 5)) {
                        backgroundChanger()
                    }
                })
                .onAppear {
                    withAnimation(.spring) {
                        backgroundChanger()
                    }
                }
                .onChange(of: changeOfView) { oldValue, newValue in
                    withAnimation(.easeInOut(duration: 1.5)) {
                        backgroundChanger()
                    }
                }
        }
    }
}

extension BackgroundView {
    private func backgroundChanger() {
        if self.start == UnitPoint(x: 4, y: 0) {
            self.start = UnitPoint(x: 0,y: -2)
            self.end = UnitPoint(x:4, y: 0)
        } else {
            self.start = UnitPoint(x: 4, y: 0)
            self.end = UnitPoint(x: 0, y: 2)
            self.start = UnitPoint(x: -4, y: 20)
            self.start = UnitPoint(x: 4, y: 0)
        }
    }
}

#Preview {
    BackgroundView(changeOfView: .constant(true))
}
