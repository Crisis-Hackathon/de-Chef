//
//  NetworkManager.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 17/02/24.
//

import Foundation


final class NetworkManager {
    
    func getResponse(url: String = "http://172.24.200.102:5000/", text: String) async throws -> [String: String] {
        guard let url = URL(string: url+text) else {
            throw URLError(.badURL)
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        guard let httpResponse = response as? HTTPURLResponse,
           httpResponse.statusCode >= 200 && httpResponse.statusCode < 300 else {
            print("[] Bad server response")
            throw URLError(.badServerResponse)
        }
        let text = try JSONDecoder().decode([String: String].self, from: data)
        return text
    }
    
    
}


