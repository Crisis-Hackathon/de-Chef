//
//  ContentView2Model.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 18/02/24.
//

import SwiftUI
import CoreML
import PhotosUI


@MainActor
final class Content2ViewModel: ObservableObject {
    
    @Published var image: [UIImage?] = []
    @Published var prediction: [String] = []
    @Published var recipePagePressed: Bool = false
    
    @Published var selectedItem: [PhotosPickerItem] = [] {
        didSet {
            imageDidSet(from: selectedItem)
        }
    }
    
    
    private func imageDidSet(from selection: [PhotosPickerItem]?) {
        guard let selection else { return }
        
        Task {
            self.image = []
            for i in selection {
                if let data = try? await i.loadTransferable(type: Data.self) {
                    if let uiimage = UIImage(data: data) {
                        self.image.append(uiimage)
                    }
                }
            }
            return
        }
    }
    
    
    func convertImage(image: UIImage) -> CVPixelBuffer? {
        
        let newSize = CGSize(width: 224.0, height: 224.0)
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(origin: CGPoint.zero, size: newSize))
        
        guard let resizedImage = UIGraphicsGetImageFromCurrentImageContext() else {
            return nil
        }
        
        UIGraphicsEndImageContext()
        
        // convert to pixel buffer
        
        let attributes = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
                  kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(newSize.width),
                                         Int(newSize.height),
                                         kCVPixelFormatType_32ARGB,
                                         attributes,
                                         &pixelBuffer)
        
        guard let createdPixelBuffer = pixelBuffer, status == kCVReturnSuccess else {
            return nil
        }
        
        CVPixelBufferLockBaseAddress(createdPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(createdPixelBuffer)
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(data: pixelData,
                                      width: Int(newSize.width),
                                      height: Int(newSize.height),
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(createdPixelBuffer),
                                      space: colorSpace,
                                      bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else {
            return nil
        }
        
        context.translateBy(x: 0, y: newSize.height)
        context.scaleBy(x: 1.0, y: -1.0)
        
        UIGraphicsPushContext(context)
        resizedImage.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(createdPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        
        return createdPixelBuffer
    }
    
    
    func getImage(uimage: UIImage) {
        do {
            let config = MLModelConfiguration()
            let model = try FruitsClassifierMl1version(configuration: config)
            if let pixelImage = convertImage(image: uimage) {
                self.prediction.append(try model.prediction(image: pixelImage).target)
            }
            
        } catch {
            print(error)
        }
    }
    
}
