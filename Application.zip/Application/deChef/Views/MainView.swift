//
//  MainView.swift
//  deChef
//
//  Created by Muhammadjon Madaminov on 18/02/24.
//

import SwiftUI



struct MainView: View {
    @State var pagePressed: Bool = false
    @State var selection: TabSelection = .home
    
    
    var body: some View {
        ZStack {
            BackgroundView(changeOfView: $pagePressed)
                .ignoresSafeArea()
            
            
            VStack(spacing: 0) {
                switch selection {
                case .home:
                    ContentView2()
                case .history:
                    Text("history")
                    Spacer()
                case .saved:
                    Text("saved")
                    Spacer()
                case .profile:
                    Text("Profile")
                    Spacer()
                case .add:
                    AskView()
                }
                
                CustomTabBar(selectedTab: $selection)
            }
            .ignoresSafeArea(.keyboard, edges: .bottom)
        }
    }
}

#Preview {
    MainView()
}
