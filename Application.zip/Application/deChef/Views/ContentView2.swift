//
//  ContentView2.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 17/02/24.
//

import SwiftUI
import CoreML
import PhotosUI




struct ContentView2: View {
    @StateObject private var vm = Content2ViewModel()
    
    
    var body: some View {
        ZStack {
            
            VStack {
                
                HStack {
                    Text("Discover")
                        .foregroundStyle(Color.white)
                        .font(.title2)
                        .fontWeight(.bold)
                        .fontDesign(.rounded)
                }
                .padding(.bottom)
            

                ImageSwipeView(goodsArray: $vm.image)
                    
                
                PhotosPickerView()
                    .glassBlurView()
                
                GoodsArrayView()
                
                NavLinkView()
                
                
            }
            .onChange(of: vm.image, { oldValue, newValue in
                vm.prediction = []
                for image in vm.image {
                    if let image = image {
                        vm.getImage(uimage: image)
                    }
                }
            })
            .padding(.bottom)
            .padding()
        }
        .fontDesign(.rounded)
    }
}


extension ContentView2 {
    @ViewBuilder private func NavLinkView() -> some View {
        VStack {
            NavigationLink {
                RecommenderView(goodsArray: vm.prediction)
            } label: {
                Text("Find recipe")
                    .font(.title.bold())
                    .padding()
                    .frame(maxWidth: .infinity)
                    .foregroundStyle(Color.white)
                    .glassBlurView(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            .onTapGesture {
                vm.recipePagePressed.toggle()
            }
            .disabled(vm.prediction.count < 1)
            .opacity(vm.prediction.count < 1 ? 0.6 : 1)
        }
        
        
    }
    
    
    @ViewBuilder private func PhotosScrollView() -> some View {
//        ScrollView(.horizontal) {
//            HStack {
//                ForEach(vm.image, id: \.self) { image in
//                    Image(uiImage: image)
//                        .resizable()
//                        .scaledToFit()
//                        .frame(width: 300, height: 400)
//                        .clipShape(RoundedRectangle(cornerRadius: 20))
//                }
//            }
//        }
//        ImageSwipeView(goodsArray: vm.image)
    }
    
    
    @ViewBuilder private func PhotosPickerView() -> some View {
        PhotosPicker(selection: $vm.selectedItem) {
            VStack {
                if vm.prediction.count < 1 {
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(.white, style: StrokeStyle(lineWidth: 3.5, lineCap: .butt, dash: [10]))
                        .overlay(content: {
                            Image(systemName: "photo.on.rectangle")
                                .resizable()
                                .frame(width: 130, height: 115)
                                .opacity(0.5)
                                .foregroundStyle(Color.white)
                        })
                        .padding()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                } else {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundStyle(Color.clear)
                        .overlay(content: {
                            HStack {
                                Image(systemName: "photo.on.rectangle")
                                Text("Add Photos")
                                    .font(.headline)
                            }
                            .tint(Color.white)
                        })
                        .frame(maxWidth: .infinity)
                        .frame(height: 60)
                        .glassBlurView()
                }
            }
            
            
        }
    }
    
    
    @ViewBuilder private func GoodsArrayView() -> some View {
        ScrollView {
            ForEach(vm.prediction, id: \.self) { prediction in
                Text(prediction)
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.cyan)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
        .frame(maxWidth: .infinity)
    }
    
    
}


#Preview {
    NavigationStack {
        ContentView2()
    }
}


