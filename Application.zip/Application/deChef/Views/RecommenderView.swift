//
//  RecommenderView.swift
//  Application
//
//  Created by Muhammadjon Madaminov on 17/02/24.
//

import CoreML
import UIKit
import SwiftUI





@MainActor
final class RecommenderViewModel: ObservableObject {
    
    @Published var prediction: String? = nil
    @Published var response: String = "Write something"
    @Published var boolean: Bool = true
    
    private let manager = NetworkManager()
    
    
    func getTextOfArray(arr: [String]) -> String {
        var txt: String = ""
        for i in arr {
            txt += i
        }
        return txt
    }
    
    
    func sendRequest(input: String) {
        Task {
            do {
                self.prediction = try await manager.getResponse(text:input).values.first
            } catch {
                print(error)
            }
        }
    }
    
}



struct RecommenderView: View {
    @StateObject private var vm = RecommenderViewModel()
    let goodsArray: [String]
    @State var notFirst: Bool = false
    @State var buttonPressed: Bool = false
    
    
    var body: some View {
        ZStack {
            
            BackgroundView(changeOfView: $vm.boolean)
                .ignoresSafeArea()
            
            VStack {
                
                ScrollView(.horizontal) {
                    HStack {
                        ForEach(goodsArray, id: \.self) { goods in
                            Text(goods)
                                .font(.headline)
                                .padding()
                                .padding(.horizontal)
                                .background(Color.cyan)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            
                        }
                    }
                }
                
                
                VStack {
                    ScrollView {
                        if let prediction = vm.prediction {
                            Text(prediction)
                                .font(.headline)
                                .foregroundStyle(Color.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.leading)
                                .glassBlurView()
                        } else {
                            ProgressView()
                        }
                    }
                }
                .padding()
                
                VStack {
    //                TextField("Write something", text: $vm.response)
    //                    .padding()
    //                    .frame(maxWidth: .infinity)
    //                    .background(Color.gray.opacity(0.3))
    //                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    if notFirst {
                        Button(action: {
                            vm.sendRequest(input: "Please write me another top 3 recipes, with the \(vm.getTextOfArray(arr: goodsArray)) ingredients.")
                            buttonPressed.toggle()
                        }, label: {
                            Text("Find Other Recipes")
                                .foregroundStyle(Color.white)
                                .font(.headline)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.accentColor)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        })
                    }
                }
                .padding(.horizontal)
            }
            .padding(.bottom)
        }
        .onAppear(perform: {
            vm.sendRequest(input: "Please write me top 3 recipes, with the \(vm.getTextOfArray(arr: goodsArray)) ingredients.")
        })
        .onChange(of: vm.prediction, { oldValue, newValue in
            notFirst = true
        })
        .onChange(of: buttonPressed) { oldValue, newValue in
            vm.prediction = nil
        }
    }
}

#Preview {
    RecommenderView(goodsArray: ["apple", "potato"])
}
