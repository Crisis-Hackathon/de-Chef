//
//  AskView.swift
//  deChef
//
//  Created by Muhammadjon Madaminov on 18/02/24.
//

import CoreML
import UIKit
import SwiftUI





@MainActor
final class AskViewModel: ObservableObject {
    
    @Published var prediction: String? = nil
    @Published var response: String = ""
    @Published var boolean: Bool = true
    
    private let manager = NetworkManager()
    
    
    func getTextOfArray(arr: [String]) -> String {
        var txt: String = ""
        for i in arr {
            txt += i
        }
        return txt
    }
    
    
    func sendRequest(input: String) {
        Task {
            do {
                self.prediction = try await manager.getResponse(text:input).values.first
            } catch {
                print(error)
            }
        }
    }
    
}

struct AskView: View {
    @StateObject private var vm = AskViewModel()
    @State var notFirst: Bool = false
    @State var buttonPressed: Bool = false
    
    
    var body: some View {
        ZStack {
            
            VStack {
                
                
                VStack {
                    VStack {
                        TextField("Write something", text: $vm.response)
                            .foregroundStyle(Color.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .glassBlurView()
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay(alignment: .trailing) {
                                Button(action: {
                                    vm.sendRequest(input: "Please write me another top 3 recipes, with the \(vm.response) ingredients.")
                                    buttonPressed.toggle()
                                    vm.response = ""
                                }, label: {
                                    Image(systemName: "arrow.up")
                                        .foregroundStyle(Color.white)
                                        .font(.headline)
                                        .padding()
                                        .background(Color.accentColor)
                                        .clipShape(RoundedRectangle(cornerRadius: 20))
                                })
                            }
                    }
                    .padding(.horizontal)
                    
                    ScrollView {
                        if let prediction = vm.prediction {
                            Text(prediction)
                                .font(.headline)
                                .foregroundStyle(Color.white)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.leading)
                                .glassBlurView(.white)
                        } else {
                            ProgressView()
                        }
                    }
                }
                .padding()
            }
            .padding(.bottom)
        }
        .onAppear(perform: {
            vm.sendRequest(input: "Please write me top 3 recipes, with the \(vm.response) ingredients.")
        })
        .onChange(of: vm.prediction, { oldValue, newValue in
            notFirst = true
        })
        .onChange(of: buttonPressed) { oldValue, newValue in
            vm.prediction = nil
        }
    }
}

#Preview {
    AskView()
}
